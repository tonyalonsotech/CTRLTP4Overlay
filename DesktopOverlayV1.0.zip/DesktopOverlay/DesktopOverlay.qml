import QtQuick 2.0
import QtQuick.Window 2.0

import "Config" as Config
import "FX" as FX

Item {
    id: root

    Config.Layout1920 {
        id: layout
    }

    Window {
        id: fxWindow1

        x: layout.fx1X
        y: layout.fx1Y

        width: layout.fx1Width
        height: layout.fx1Height

        visible: true
        color: "transparent"

        title: "Traktor FX Overlay 1"

        flags: Qt.FramelessWindowHint
             | Qt.WindowStaysOnTopHint
             | Qt.Tool

        FX.FXUnit {
            anchors.fill: parent

            fxUnit: 1

            parameterXPositions: layout.fxParameterX
            parameterWidths: layout.fxParameterWidths
            parameterHeight: layout.parameterHeight

            labelFontSize: layout.labelFontSize
            valueFontSize: layout.valueFontSize

            labelColor: layout.labelColor
            valueColor: layout.valueColor
            disabledColor: layout.disabledColor
            valueBackgroundColor: layout.valueBackgroundColor

            debugMode: layout.debugMode
            debugBorderColor: layout.debugBorderColor
            debugTextColor: layout.debugTextColor
            debugFontSize: layout.debugFontSize

            buttonXPositions: layout.fxButtonX
            buttonY: layout.fxButtonY
            buttonWidths: layout.fxButtonWidths
            buttonHeight: layout.fxButtonHeight
            buttonFontSize: layout.fxButtonFontSize

            buttonInactiveBackgroundColor:
                layout.fxButtonInactiveBackgroundColor

            buttonActiveBackgroundColor:
                layout.fxButtonActiveBackgroundColor

            buttonInactiveTextColor:
                layout.fxButtonInactiveTextColor

            buttonActiveTextColor:
                layout.fxButtonActiveTextColor

            selectPreviousX: layout.fxSelectPreviousX
            selectNextX: layout.fxSelectNextX
            selectButtonY: layout.fxSelectButtonY

            selectButtonWidth: layout.fxSelectButtonWidth
            selectButtonHeight: layout.fxSelectButtonHeight
            selectButtonFontSize: layout.fxSelectButtonFontSize

            selectButtonBackgroundColor:
                layout.fxSelectButtonBackgroundColor

            selectButtonPressedColor:
                layout.fxSelectButtonPressedColor

            selectButtonTextColor:
                layout.fxSelectButtonTextColor

            selectLabelX: layout.fxSelectLabelX
            selectLabelWidth: layout.fxSelectLabelWidth              
        }
    }

    Window {
        id: fxWindow2

        x: layout.fx2X
        y: layout.fx2Y

        width: layout.fx2Width
        height: layout.fx2Height

        visible: true
        color: "transparent"

        title: "Traktor FX Overlay 2"

        flags: Qt.FramelessWindowHint
             | Qt.WindowStaysOnTopHint
             | Qt.Tool

        FX.FXUnit {
            anchors.fill: parent

            fxUnit: 2

            parameterXPositions: layout.fxParameterX
            parameterWidths: layout.fxParameterWidths
            parameterHeight: layout.parameterHeight

            labelFontSize: layout.labelFontSize
            valueFontSize: layout.valueFontSize

            labelColor: layout.labelColor
            valueColor: layout.valueColor
            disabledColor: layout.disabledColor
            valueBackgroundColor: layout.valueBackgroundColor

            debugMode: layout.debugMode
            debugBorderColor: layout.debugBorderColor
            debugTextColor: layout.debugTextColor
            debugFontSize: layout.debugFontSize

            buttonXPositions: layout.fxButtonX
            buttonY: layout.fxButtonY
            buttonWidths: layout.fxButtonWidths
            buttonHeight: layout.fxButtonHeight
            buttonFontSize: layout.fxButtonFontSize

            buttonInactiveBackgroundColor:
                layout.fxButtonInactiveBackgroundColor

            buttonActiveBackgroundColor:
                layout.fxButtonActiveBackgroundColor

            buttonInactiveTextColor:
                layout.fxButtonInactiveTextColor

            buttonActiveTextColor:
                layout.fxButtonActiveTextColor

            selectPreviousX: layout.fxSelectPreviousX
            selectNextX: layout.fxSelectNextX
            selectButtonY: layout.fxSelectButtonY

            selectButtonWidth: layout.fxSelectButtonWidth
            selectButtonHeight: layout.fxSelectButtonHeight
            selectButtonFontSize: layout.fxSelectButtonFontSize

            selectButtonBackgroundColor:
                layout.fxSelectButtonBackgroundColor

            selectButtonPressedColor:
                layout.fxSelectButtonPressedColor

            selectButtonTextColor:
                layout.fxSelectButtonTextColor

            selectLabelX: layout.fxSelectLabelX
            selectLabelWidth: layout.fxSelectLabelWidth               
        }
    }
}