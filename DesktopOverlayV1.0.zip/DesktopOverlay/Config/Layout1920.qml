import QtQuick 2.0

QtObject {
    // Whole overlay
    property int screenWidth: 1920
    property int screenHeight: 1080

    // Windows desktop coordinates
    property int overlayX: 0
    property int overlayY: 0

    // Enable visible alignment guides.
    property bool debugMode: false

    // Left FX unit
    property int fx1X: 60
    property int fx1Y: 108
    property int fx1Width: 330
    property int fx1Height: 58

    // Right FX unit
    property int fx2X: 1557
    property int fx2Y: 108
    property int fx2Width: 330
    property int fx2Height: 58

    /*
     * Relative horizontal positions inside each FX unit.
     *
     * Index 0: Dry/Wet
     * Index 1: Knob 1
     * Index 2: Knob 2
     * Index 3: Knob 3
     *
     * These do not need to be evenly spaced.
     */
    property var fxParameterX: [
        0,
        189,
        239,
        289
    ]

    // Individual FX parameter field dimensions.
    property var fxParameterWidths: [
    74, // Dry/Wet
    48, // Knob 1
    48, // Knob 2
    48  // Knob 3
    ]
    property int parameterHeight: 34

    /*
    * Relative horizontal positions of the four FX buttons.
    *
    * Index 0: FX On
    * Index 1: FX Button 1
    * Index 2: FX Button 2
    * Index 3: FX Button 3
    */
    property var fxButtonX: [
        75,
        102,
        129,
        156
    ]

    property int fxButtonY: 17

    property var fxButtonWidths: [
        25,
        25,
        25,
        25
    ]    

    property int fxButtonHeight: 17

    property int fxButtonFontSize: 8

    property color fxButtonInactiveBackgroundColor: "#181818"
    property color fxButtonActiveBackgroundColor: "#f28c28"

    property color fxButtonInactiveTextColor: "#8f8f8f"
    property color fxButtonActiveTextColor: "#181818"

    /*
    * Previous and next effect-selection buttons.
    *
    * These sit above the ON/1/2/3 buttons in the value row.
    */
    property int fxSelectPreviousX: 82
    property int fxSelectLabelX: 104
    property int fxSelectNextX: 156
    property int fxSelectButtonY: 0

    property int fxSelectButtonWidth: 20
    property int fxSelectLabelWidth: 50
    property int fxSelectButtonHeight: 17

    property int fxSelectButtonFontSize: 11

    property color fxSelectButtonBackgroundColor: "#181818"
    property color fxSelectButtonPressedColor: "#303030"
    property color fxSelectButtonTextColor: "#d0d0d0"  

    // Text appearance
    property int labelFontSize: 9
    property int valueFontSize: 11

    property color labelColor: "#8f8f8f"
    property color valueColor: "#d0d0d0"
    property color disabledColor: "#5c5c5c"

    // Background color for each FX value.
    property color valueBackgroundColor: "#181818"

    // Debug appearance
    property color debugBorderColor: "#ff3030"
    property color debugTextColor: "#ff8080"
    property int debugFontSize: 8
}