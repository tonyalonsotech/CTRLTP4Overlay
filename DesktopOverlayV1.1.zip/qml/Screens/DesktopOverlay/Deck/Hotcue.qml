import CSI 1.0
import QtQuick 2.0

Item {
    id: root

    property int deck: 1
    property int hotcue: 1

    property int fontSize: 10
    property color activeTextColor: "#181818"
    property color inactiveTextColor: "#5c5c5c"
    property color activeBackgroundColor: "#7fd7ff"
    property color inactiveBackgroundColor: "#181818"
    property color pressedBackgroundColor: "#b7eaff"
    property color borderColor: "#303030"

    property bool debugMode: false
    property color debugBorderColor: "#ff3030"
    property color debugTextColor: "#ff8080"
    property int debugFontSize: 8

    AppProperty {
        id: hotcueName
        path: "app.traktor.decks."
              + root.deck
              + ".track.cue.hotcues."
              + root.hotcue
              + ".name"
    }

    AppProperty {
        id: hotcueExists
        path: "app.traktor.decks."
              + root.deck
              + ".track.cue.hotcues."
              + root.hotcue
              + ".exists"
    }

    // This is a momentary control. Setting it true presses the hotcue;
    // returning it to false releases it.
    AppProperty {
        id: hotcueActive
        path: "app.traktor.decks."
              + root.deck
              + ".track.cue.hotcues."
              + root.hotcue
              + ".active"
    }

    function normalizedName(value) {
        if (value === undefined || value === null) {
            return ""
        }

        var text = String(value).trim()

        if (text === "n.n." || text === "n.n") {
            return ""
        }

        return text
    }

    function releaseHotcue() {
        hotcueActive.value = false
    }

    property string cueName: normalizedName(hotcueName.value)
    property bool hasHotcue: Boolean(hotcueExists.value)
    property bool hasName: cueName.length > 0

    Rectangle {
        anchors.fill: parent

        color: mouseArea.pressed
               ? root.pressedBackgroundColor
               : (root.hasHotcue
                  ? root.activeBackgroundColor
                  : root.inactiveBackgroundColor)

        border.width: root.debugMode ? 1 : 0
        border.color: root.debugMode
                      ? root.debugBorderColor
                      : root.borderColor
        radius: 2

        Text {
            anchors.fill: parent
            anchors.leftMargin: 4
            anchors.rightMargin: 4

            text: root.hasName ? root.cueName : ""
            color: root.hasHotcue
                   ? root.activeTextColor
                   : root.inactiveTextColor

            font.pixelSize: root.fontSize
            font.bold: root.hasHotcue

            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter

            elide: Text.ElideRight
        }

        Text {
            visible: root.debugMode
            anchors.left: parent.left
            anchors.top: parent.top
            anchors.margins: 1

            text: root.hotcue
            color: root.debugTextColor
            font.pixelSize: root.debugFontSize
        }
    }

    MouseArea {
        id: mouseArea

        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor

        onPressed: hotcueActive.value = true
        onReleased: root.releaseHotcue()
        onCanceled: root.releaseHotcue()
    }
}
