import QtQuick 2.0

Item {
    id: root

    property int deck: 1

    property int hotcueCount: 8
    property int hotcueWidth: 78
    property int hotcueHeight: 20
    property int hotcueSpacing: 4

    property int hotcueFontSize: 10
    property color hotcueActiveTextColor: "#181818"
    property color hotcueInactiveTextColor: "#5c5c5c"
    property color hotcueActiveBackgroundColor: "#7fd7ff"
    property color hotcueInactiveBackgroundColor: "#181818"
    property color hotcuePressedBackgroundColor: "#b7eaff"
    property color hotcueBorderColor: "#303030"

    property bool debugMode: false
    property color debugBorderColor: "#ff3030"
    property color debugTextColor: "#ff8080"
    property int debugFontSize: 8

    HotcueRow {
        anchors.fill: parent

        deck: root.deck
        hotcueCount: root.hotcueCount

        cellWidth: root.hotcueWidth
        cellHeight: root.hotcueHeight
        spacing: root.hotcueSpacing

        fontSize: root.hotcueFontSize
        activeTextColor: root.hotcueActiveTextColor
        inactiveTextColor: root.hotcueInactiveTextColor
        activeBackgroundColor: root.hotcueActiveBackgroundColor
        inactiveBackgroundColor: root.hotcueInactiveBackgroundColor
        pressedBackgroundColor: root.hotcuePressedBackgroundColor
        borderColor: root.hotcueBorderColor

        debugMode: root.debugMode
        debugBorderColor: root.debugBorderColor
        debugTextColor: root.debugTextColor
        debugFontSize: root.debugFontSize
    }
}
