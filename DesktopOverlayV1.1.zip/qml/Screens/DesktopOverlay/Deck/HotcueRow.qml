import QtQuick 2.0

Item {
    id: root

    property int deck: 1
    property int hotcueCount: 8

    property int cellWidth: 78
    property int cellHeight: 20
    property int spacing: 4

    property int fontSize: 10
    property color activeTextColor: "#181818"
    property color inactiveTextColor: "#5c5c5c"
    property color activeBackgroundColor: "#7fd7ff"
    property color inactiveBackgroundColor: "#181818"
    property color pressedBackgroundColor: "#b7eaff"
    property color borderColor: "#303030"

    property bool debugMode: false
    property color debugBorderColor: "#ff3030"
    property color debugTextColor: "#ff8080"
    property int debugFontSize: 8

    Repeater {
        model: root.hotcueCount

        Hotcue {
            x: index * (root.cellWidth + root.spacing)
            y: 0

            width: root.cellWidth
            height: root.cellHeight

            deck: root.deck
            hotcue: index + 1

            fontSize: root.fontSize
            activeTextColor: root.activeTextColor
            inactiveTextColor: root.inactiveTextColor
            activeBackgroundColor: root.activeBackgroundColor
            inactiveBackgroundColor: root.inactiveBackgroundColor
            pressedBackgroundColor: root.pressedBackgroundColor
            borderColor: root.borderColor

            debugMode: root.debugMode
            debugBorderColor: root.debugBorderColor
            debugTextColor: root.debugTextColor
            debugFontSize: root.debugFontSize
        }
    }
}
