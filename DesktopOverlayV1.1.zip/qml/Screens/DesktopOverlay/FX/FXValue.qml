import CSI 1.0
import QtQuick 2.0

Item {
    id: root

    property AppProperty parameter
    property string label: ""
    property bool enabled: true

    property int labelFontSize: 9
    property int valueFontSize: 11

    property color labelColor: "#8f8f8f"
    property color valueColor: "#d0d0d0"
    property color disabledColor: "#5c5c5c"
    property color valueBackgroundColor: "#181818"

    property string displayedLabel: enabled ? label : ""
    property string displayedValue: enabled && parameter
                                    ? parameter.description
                                    : ""

    implicitWidth: 74
    implicitHeight: 34

    Rectangle {
        id: valueBackground

        anchors.fill: parent

        color: root.valueBackgroundColor
        radius: 2

        Text {
            id: parameterValue

            anchors {
                top: parent.top
                left: parent.left
                right: parent.right
            }

            height: 17

            text: root.displayedValue
            color: root.enabled
                   ? root.valueColor
                   : root.disabledColor

            font.pixelSize: root.valueFontSize
            font.bold: false

            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter

            elide: Text.ElideRight
        }

        Text {
            id: parameterLabel

            anchors {
                top: parameterValue.bottom
                left: parent.left
                right: parent.right
            }

            height: 15

            text: root.displayedLabel
            color: root.enabled
                   ? root.labelColor
                   : root.disabledColor

            font.pixelSize: root.labelFontSize
            font.capitalization: Font.AllUppercase

            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter

            elide: Text.ElideRight
        }
    }
}