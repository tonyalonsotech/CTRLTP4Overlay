import CSI 1.0
import QtQuick 2.0

Item {
    id: root

    property int fxUnit: 1

    property var parameterXPositions: [
        0,
        82,
        159,
        241
    ]

    property var buttonXPositions: [
        80,
        107,
        134,
        161
    ]

    property int buttonY: 17

    property var buttonWidths: [
        25,
        25,
        25,
        25
    ]

    property int buttonHeight: 17
    property int buttonFontSize: 8

    property color buttonInactiveBackgroundColor: "#181818"
    property color buttonActiveBackgroundColor: "#f28c28"

    property color buttonInactiveTextColor: "#8f8f8f"
    property color buttonActiveTextColor: "#181818"    

    property var parameterWidths: [
    74,
    48,
    48,
    48
    ]
    property int parameterHeight: 34

    property int labelFontSize: 9
    property int valueFontSize: 11

    property color labelColor: "#8f8f8f"
    property color valueColor: "#d0d0d0"
    property color disabledColor: "#5c5c5c"
    property color valueBackgroundColor: "#181818"

    property bool debugMode: false
    property color debugBorderColor: "#ff3030"
    property color debugTextColor: "#ff8080"
    property int debugFontSize: 8

    property int selectPreviousX: 90
    property int selectNextX: 140
    property int selectButtonY: 0

    property int selectButtonWidth: 36
    property int selectButtonHeight: 17
    property int selectButtonFontSize: 11

    property color selectButtonBackgroundColor: "#181818"
    property color selectButtonPressedColor: "#303030"
    property color selectButtonTextColor: "#d0d0d0"

    property int selectLabelX: 104
    property int selectLabelWidth: 50

    AppProperty {
        id: fxUnitMode
        path: "app.traktor.fx." + root.fxUnit + ".type"
    }

    AppProperty {
        id: fxSelect1
        path: "app.traktor.fx."
            + root.fxUnit
            + ".select.1"
    }    

    /*
     * Returns the Traktor property path for a parameter value.
     *
     * Index 0 is Dry/Wet.
     * Indexes 1–3 are the three effect parameters.
     */
    function valuePath(parameterIndex) {
        if (parameterIndex === 0) {
            return "app.traktor.fx."
                    + root.fxUnit
                    + ".dry_wet";
        }

        return "app.traktor.fx."
                + root.fxUnit
                + ".parameters."
                + parameterIndex;
    }

    /*
     * Returns the Traktor property path for the parameter name.
     *
     * Dry/Wet does not require a separate name property.
     */
    function namePath(parameterIndex) {
        if (parameterIndex === 0) {
            return "";
        }

        return "app.traktor.fx."
                + root.fxUnit
                + ".knobs."
                + parameterIndex
                + ".name";
    }

    function parameterLabel(parameterIndex, nameValue) {
        if (parameterIndex === 0) {
            return "DRY/WET";
        }

        if (nameValue === undefined || nameValue === null) {
            return "";
        }

        return nameValue;
    }

    /*
    * Index 0 is the FX Unit On button.
    * Indexes 1–3 are the effect-specific buttons.
    */
    function buttonPath(buttonIndex) {
        if (buttonIndex === 0) {
            return "app.traktor.fx."
                    + root.fxUnit
                    + ".enabled";
        }

        return "app.traktor.fx."
                + root.fxUnit
                + ".buttons."
                + buttonIndex;
    }

    function buttonNamePath(buttonIndex) {
        if (buttonIndex === 0) {
            return "";
        }

        return "app.traktor.fx."
                + root.fxUnit
                + ".buttons."
                + buttonIndex
                + ".name";
    }

    function buttonLabel(buttonIndex, nameValue) {
        if (buttonIndex === 0) {
            return "ON";
        }

        if (nameValue === undefined
                || nameValue === null
                || nameValue === "") {
            return buttonIndex.toString();
        }

        return nameValue;
    }


    /*
    * FX Previous and Next buttons
    */  

    FXSelectButton {
        id: previousEffectButton

        x: root.selectPreviousX
        y: root.selectButtonY

        width: root.selectButtonWidth
        height: root.selectButtonHeight

        symbol: "\u25C0"

        fontSize: root.selectButtonFontSize

        backgroundColor: root.selectButtonBackgroundColor
        pressedBackgroundColor: root.selectButtonPressedColor
        textColor: root.selectButtonTextColor

        onClicked: {
            var currentValue = Number(fxSelect1.value)

            if (!isNaN(currentValue) && currentValue > 0) {
                fxSelect1.value = currentValue - 1
            }
        }
    }

    Text {
        id: selectLabel

        x: root.selectLabelX
        y: root.selectButtonY

        width: root.selectLabelWidth
        height: root.selectButtonHeight

        text: "SELECT"
        color: root.labelColor

        font.pixelSize: root.labelFontSize
        font.capitalization: Font.AllUppercase

        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter

        elide: Text.ElideNone
        clip: false
    }   

    FXSelectButton {
        id: nextEffectButton

        x: root.selectNextX
        y: root.selectButtonY

        width: root.selectButtonWidth
        height: root.selectButtonHeight

        symbol: "\u25B6"

        fontSize: root.selectButtonFontSize

        backgroundColor: root.selectButtonBackgroundColor
        pressedBackgroundColor: root.selectButtonPressedColor
        textColor: root.selectButtonTextColor

        onClicked: {
            var currentValue = Number(fxSelect1.value)

            if (!isNaN(currentValue)) {
                fxSelect1.value = currentValue + 1
            }
        }
    }

    Repeater {
        model: 4

        delegate: Item {
            id: parameterDelegate

            property int parameterIndex: index

            x: root.parameterXPositions[parameterIndex]
            y: 0

            width: root.parameterWidths[parameterIndex]
            height: root.parameterHeight

            AppProperty {
                id: parameterValue

                path: root.valuePath(
                          parameterDelegate.parameterIndex
                      )
            }

            AppProperty {
                id: parameterName

                path: root.namePath(
                          parameterDelegate.parameterIndex
                      )
            }

            FXValue {
                anchors.fill: parent

                parameter: parameterValue

                label: root.parameterLabel(
                           parameterDelegate.parameterIndex,
                           parameterName.value
                       )

                enabled: true

                labelFontSize: root.labelFontSize
                valueFontSize: root.valueFontSize

                labelColor: root.labelColor
                valueColor: root.valueColor
                disabledColor: root.disabledColor
                valueBackgroundColor: root.valueBackgroundColor
            }

            Rectangle {
                anchors.fill: parent

                visible: root.debugMode
                color: "transparent"

                border.width: 1
                border.color: root.debugBorderColor
            }

            Text {
                visible: root.debugMode

                anchors {
                    left: parent.left
                    bottom: parent.top
                    bottomMargin: 1
                }

                text: "FX"
                      + root.fxUnit
                      + ":"
                      + parameterDelegate.parameterIndex
                      + "  x="
                      + parameterDelegate.x

                color: root.debugTextColor
                font.pixelSize: root.debugFontSize
            }
        }
    }

    Repeater {
        model: 4

        delegate: Item {
            id: buttonDelegate

            property int buttonIndex: index

            x: root.buttonXPositions[buttonIndex]
            y: root.buttonY

            width: root.buttonWidths[buttonIndex]
            height: root.buttonHeight

            AppProperty {
                id: buttonState

                path: root.buttonPath(
                        buttonDelegate.buttonIndex
                    )
            }

            AppProperty {
                id: buttonName

                path: root.buttonNamePath(
                        buttonDelegate.buttonIndex
                    )
            }

            FXButton {
                anchors.fill: parent

                buttonProperty: buttonState

                label: root.buttonLabel(
                        buttonDelegate.buttonIndex,
                        buttonName.value
                    )

                fontSize: root.buttonFontSize

                inactiveBackgroundColor:
                    root.buttonInactiveBackgroundColor

                activeBackgroundColor:
                    root.buttonActiveBackgroundColor

                inactiveTextColor:
                    root.buttonInactiveTextColor

                activeTextColor:
                    root.buttonActiveTextColor
            }

            Rectangle {
                anchors.fill: parent

                visible: root.debugMode
                color: "transparent"

                border.width: 1
                border.color: root.debugBorderColor
            }

            Text {
                visible: root.debugMode

                anchors {
                    left: parent.left
                    bottom: parent.top
                    bottomMargin: 1
                }

                text: "B"
                    + buttonDelegate.buttonIndex
                    + " x="
                    + buttonDelegate.x
                    + " y="
                    + buttonDelegate.y

                color: root.debugTextColor
                font.pixelSize: root.debugFontSize
            }
        }
    }    

    Rectangle {
        anchors.fill: parent

        visible: root.debugMode
        color: "transparent"

        border.width: 1
        border.color: root.debugBorderColor
    }

    Text {
        visible: root.debugMode

        anchors {
            left: parent.left
            top: parent.bottom
            topMargin: 2
        }

        text: "FX Unit "
              + root.fxUnit
              + "  "
              + root.width
              + "x"
              + root.height

        color: root.debugTextColor
        font.pixelSize: root.debugFontSize
    }
}