import CSI 1.0
import QtQuick 2.0

Item {
    id: root

    property AppProperty buttonProperty
    property string label: ""

    property color inactiveBackgroundColor: "#181818"
    property color activeBackgroundColor: "#f28c28"

    property color inactiveTextColor: "#8f8f8f"
    property color activeTextColor: "#181818"

    property int fontSize: 9

    property bool active: buttonProperty
                          ? Boolean(buttonProperty.value)
                          : false

    Rectangle {
        anchors.fill: parent

        color: root.active
               ? root.activeBackgroundColor
               : root.inactiveBackgroundColor

        Text {
            anchors.fill: parent
            anchors.leftMargin: 2
            anchors.rightMargin: 2

            text: root.label

            color: root.active
                   ? root.activeTextColor
                   : root.inactiveTextColor

            font.pixelSize: root.fontSize
            font.bold: root.active

            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter

            elide: Text.ElideRight
        }
    }

    MouseArea {
        anchors.fill: parent

        cursorShape: Qt.PointingHandCursor

        onClicked: {
            if (root.buttonProperty) {
                root.buttonProperty.value =
                    !Boolean(root.buttonProperty.value);
            }
        }
    }
}