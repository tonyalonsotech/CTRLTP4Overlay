import QtQuick 2.0

import "../Config" as Config

Item {
    id: root

    Config.Layout1920 {
        id: layout
    }

    FXUnit {
        id: fxUnit1

        x: layout.fx1X
        y: layout.fx1Y

        width: layout.fx1Width
        height: layout.fx1Height

        fxUnit: 1

        parameterXPositions: layout.fxParameterX
        parameterWidths: layout.fxParameterWidths
        parameterHeight: layout.parameterHeight

        labelFontSize: layout.labelFontSize
        valueFontSize: layout.valueFontSize

        labelColor: layout.labelColor
        valueColor: layout.valueColor
        disabledColor: layout.disabledColor
        valueBackgroundColor: layout.valueBackgroundColor

        debugMode: layout.debugMode
        debugBorderColor: layout.debugBorderColor
        debugTextColor: layout.debugTextColor
        debugFontSize: layout.debugFontSize

        buttonXPositions: layout.fxButtonX
        buttonY: layout.fxButtonY
        buttonWidths: layout.fxButtonWidths
        buttonHeight: layout.fxButtonHeight
        buttonFontSize: layout.fxButtonFontSize

        buttonInactiveBackgroundColor:
            layout.fxButtonInactiveBackgroundColor

        buttonActiveBackgroundColor:
            layout.fxButtonActiveBackgroundColor

        buttonInactiveTextColor:
            layout.fxButtonInactiveTextColor

        buttonActiveTextColor:
            layout.fxButtonActiveTextColor
    }

    FXUnit {
        id: fxUnit2

        x: layout.fx2X
        y: layout.fx2Y

        width: layout.fx2Width
        height: layout.fx2Height

        fxUnit: 2

        parameterXPositions: layout.fxParameterX
        parameterWidths: layout.fxParameterWidths
        parameterHeight: layout.parameterHeight

        labelFontSize: layout.labelFontSize
        valueFontSize: layout.valueFontSize

        labelColor: layout.labelColor
        valueColor: layout.valueColor
        disabledColor: layout.disabledColor
        valueBackgroundColor: layout.valueBackgroundColor

        debugMode: layout.debugMode
        debugBorderColor: layout.debugBorderColor
        debugTextColor: layout.debugTextColor
        debugFontSize: layout.debugFontSize

        buttonXPositions: layout.fxButtonX
        buttonY: layout.fxButtonY
        buttonWidths: layout.fxButtonWidths
        buttonHeight: layout.fxButtonHeight
        buttonFontSize: layout.fxButtonFontSize

        buttonInactiveBackgroundColor:
            layout.fxButtonInactiveBackgroundColor

        buttonActiveBackgroundColor:
            layout.fxButtonActiveBackgroundColor

        buttonInactiveTextColor:
            layout.fxButtonInactiveTextColor

        buttonActiveTextColor:
            layout.fxButtonActiveTextColor        
    }
}