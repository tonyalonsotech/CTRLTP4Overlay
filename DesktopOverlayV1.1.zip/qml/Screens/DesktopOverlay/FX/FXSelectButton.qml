import QtQuick 2.0

Item {
    id: root

    property string symbol: ""

    property color backgroundColor: "#181818"
    property color pressedBackgroundColor: "#303030"
    property color textColor: "#d0d0d0"

    property int fontSize: 11

    signal clicked()

    Rectangle {
        anchors.fill: parent

        color: mouseArea.pressed
               ? root.pressedBackgroundColor
               : root.backgroundColor

        Text {
            anchors.fill: parent

            text: root.symbol
            color: root.textColor

            font.pixelSize: root.fontSize

            horizontalAlignment: Text.AlignHCenter
            verticalAlignment: Text.AlignVCenter
        }
    }

    MouseArea {
        id: mouseArea

        anchors.fill: parent
        cursorShape: Qt.PointingHandCursor

        onClicked: root.clicked()
    }
}