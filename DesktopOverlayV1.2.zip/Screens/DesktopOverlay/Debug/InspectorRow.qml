import QtQuick 2.0

Item {
    property string label: ""
    property string value: ""
    property int fontSize: 10
    property color backgroundColor: "#181818"

    width: 420
    height: 18

    Rectangle {
        anchors.fill: parent
        color: backgroundColor
    }

    Text {
        x: 4
        width: 225
        height: parent.height

        text: parent.label
        color: "#c0c0c0"
        font.pixelSize: parent.fontSize
        verticalAlignment: Text.AlignVCenter
    }

    Text {
        x: 230
        width: parent.width - 234
        height: parent.height

        text: parent.value
        color: "#ffffff"
        font.pixelSize: parent.fontSize
        verticalAlignment: Text.AlignVCenter
        elide: Text.ElideRight
    }
}