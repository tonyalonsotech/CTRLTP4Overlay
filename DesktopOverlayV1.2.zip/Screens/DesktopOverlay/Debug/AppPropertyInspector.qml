import QtQuick 2.0

Item {
    id: root

    property int deck: 1

    width: 420
    height: 160

    Rectangle {
        anchors.fill: parent
        color: "#202020"
        border.color: "#7fd7ff"
        border.width: 1
    }

    Text {
        anchors.centerIn: parent

        text: "Inspector loaded for Deck " + root.deck
        color: "white"
        font.pixelSize: 16
    }
}