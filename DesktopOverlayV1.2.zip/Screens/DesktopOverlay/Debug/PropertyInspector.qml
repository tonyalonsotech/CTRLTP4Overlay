import QtQuick 2.0

Item {
    id: root

    property int deck: 1
    property int rowHeight: 18
    property int fontSize: 10

    width: 420
    height: propertyColumn.height + 12

    Rectangle {
        anchors.fill: parent
        color: "#e6141414"
        border.color: "#7fd7ff"
        border.width: 1
    }

    Column {
        id: propertyColumn

        x: 6
        y: 6
        width: parent.width - 12
        spacing: 1

        Text {
            width: parent.width
            height: 22

            text: "Deck " + root.deck + " Property Inspector"
            color: "#7fd7ff"
            font.pixelSize: 12
            font.bold: true
            verticalAlignment: Text.AlignVCenter
        }

        InspectorRow {
            width: parent.width
            label: "move.mode"
            value: root.safeValue(function() {
                return app.traktor.decks[root.deck].move.mode
            })
            fontSize: root.fontSize
            backgroundColor: "#202020"
        }

        InspectorRow {
            width: parent.width
            label: "move.size"
            value: root.safeValue(function() {
                return app.traktor.decks[root.deck].move.size
            })
            fontSize: root.fontSize
        }

        InspectorRow {
            width: parent.width
            label: "move"
            value: root.safeValue(function() {
                return app.traktor.decks[root.deck].move
            })
            fontSize: root.fontSize
            backgroundColor: "#202020"
        }

        InspectorRow {
            width: parent.width
            label: "track.cue"
            value: root.safeValue(function() {
                return app.traktor.decks[root.deck].track.cue
            })
            fontSize: root.fontSize
        }

        InspectorRow {
            width: parent.width
            label: "track.grid"
            value: root.safeValue(function() {
                return app.traktor.decks[root.deck].track.grid
            })
            fontSize: root.fontSize
            backgroundColor: "#202020"
        }

        InspectorRow {
            width: parent.width
            label: "track.gridmarker.move"
            value: root.safeValue(function() {
                return app.traktor.decks[root.deck].track.gridmarker.move
            })
            fontSize: root.fontSize
        }
    }

    function safeValue(getter) {
        try {
            var result = getter()

            if (result === undefined)
                return "undefined"

            if (result === null)
                return "null"

            return String(result)
        } catch (error) {
            return "unavailable"
        }
    }
}