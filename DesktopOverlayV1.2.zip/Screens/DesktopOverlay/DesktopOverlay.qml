import QtQuick 2.0
import QtQuick.Window 2.0

import "Config" as Config
import "FX" as FX
import "Deck" as Deck

Item {
    id: root

    Config.Layout1920 {
        id: layout
    }

    Deck.DeckViewState {
        id: deckABViewState
        deck: 1
    }

    Window {
        id: fxWindow1

        x: layout.fx1X
        y: layout.fx1Y

        property real displayScale: Screen.devicePixelRatio > 0 ? Screen.devicePixelRatio : 1

        width: layout.fx1Width / displayScale
        height: layout.fx1Height / displayScale
        minimumWidth: width
        maximumWidth: width
        minimumHeight: height
        maximumHeight: height

        visible: true
        color: "transparent"

        title: "Traktor FX Overlay 1"

        flags: Qt.FramelessWindowHint
             | Qt.BypassWindowManagerHint
             | Qt.WindowStaysOnTopHint
             | Qt.Tool
             | Qt.NoDropShadowWindowHint
             | Qt.WindowDoesNotAcceptFocus

        FX.FXUnit {
            width: layout.fx1Width
            height: layout.fx1Height
            scale: 1 / fxWindow1.displayScale
            transformOrigin: Item.TopLeft

            fxUnit: 1

            parameterXPositions: layout.fxParameterX
            parameterWidths: layout.fxParameterWidths
            parameterHeight: layout.parameterHeight

            labelFontSize: layout.labelFontSize
            valueFontSize: layout.valueFontSize

            labelColor: layout.labelColor
            valueColor: layout.valueColor
            disabledColor: layout.disabledColor
            valueBackgroundColor: layout.valueBackgroundColor

            debugMode: layout.debugMode
            debugBorderColor: layout.debugBorderColor
            debugTextColor: layout.debugTextColor
            debugFontSize: layout.debugFontSize

            buttonXPositions: layout.fxButtonX
            buttonY: layout.fxButtonY
            buttonWidths: layout.fxButtonWidths
            buttonHeight: layout.fxButtonHeight
            buttonFontSize: layout.fxButtonFontSize

            buttonInactiveBackgroundColor:
                layout.fxButtonInactiveBackgroundColor

            buttonActiveBackgroundColor:
                layout.fxButtonActiveBackgroundColor

            buttonInactiveTextColor:
                layout.fxButtonInactiveTextColor

            buttonActiveTextColor:
                layout.fxButtonActiveTextColor

            selectPreviousX: layout.fxSelectPreviousX
            selectNextX: layout.fxSelectNextX
            selectButtonY: layout.fxSelectButtonY

            selectButtonWidth: layout.fxSelectButtonWidth
            selectButtonHeight: layout.fxSelectButtonHeight
            selectButtonFontSize: layout.fxSelectButtonFontSize

            selectButtonBackgroundColor:
                layout.fxSelectButtonBackgroundColor

            selectButtonPressedColor:
                layout.fxSelectButtonPressedColor

            selectButtonTextColor:
                layout.fxSelectButtonTextColor

            selectLabelX: layout.fxSelectLabelX
            selectLabelWidth: layout.fxSelectLabelWidth              
        }
    }

    Window {
        id: fxWindow2

        x: layout.fx2X
        y: layout.fx2Y

        property real displayScale: Screen.devicePixelRatio > 0 ? Screen.devicePixelRatio : 1

        width: layout.fx2Width / displayScale
        height: layout.fx2Height / displayScale
        minimumWidth: width
        maximumWidth: width
        minimumHeight: height
        maximumHeight: height

        visible: true
        color: "transparent"

        title: "Traktor FX Overlay 2"

        flags: Qt.FramelessWindowHint
             | Qt.BypassWindowManagerHint
             | Qt.WindowStaysOnTopHint
             | Qt.Tool
             | Qt.NoDropShadowWindowHint
             | Qt.WindowDoesNotAcceptFocus

        FX.FXUnit {
            width: layout.fx2Width
            height: layout.fx2Height
            scale: 1 / fxWindow2.displayScale
            transformOrigin: Item.TopLeft

            fxUnit: 2

            parameterXPositions: layout.fxParameterX
            parameterWidths: layout.fxParameterWidths
            parameterHeight: layout.parameterHeight

            labelFontSize: layout.labelFontSize
            valueFontSize: layout.valueFontSize

            labelColor: layout.labelColor
            valueColor: layout.valueColor
            disabledColor: layout.disabledColor
            valueBackgroundColor: layout.valueBackgroundColor

            debugMode: layout.debugMode
            debugBorderColor: layout.debugBorderColor
            debugTextColor: layout.debugTextColor
            debugFontSize: layout.debugFontSize

            buttonXPositions: layout.fxButtonX
            buttonY: layout.fxButtonY
            buttonWidths: layout.fxButtonWidths
            buttonHeight: layout.fxButtonHeight
            buttonFontSize: layout.fxButtonFontSize

            buttonInactiveBackgroundColor:
                layout.fxButtonInactiveBackgroundColor

            buttonActiveBackgroundColor:
                layout.fxButtonActiveBackgroundColor

            buttonInactiveTextColor:
                layout.fxButtonInactiveTextColor

            buttonActiveTextColor:
                layout.fxButtonActiveTextColor

            selectPreviousX: layout.fxSelectPreviousX
            selectNextX: layout.fxSelectNextX
            selectButtonY: layout.fxSelectButtonY

            selectButtonWidth: layout.fxSelectButtonWidth
            selectButtonHeight: layout.fxSelectButtonHeight
            selectButtonFontSize: layout.fxSelectButtonFontSize

            selectButtonBackgroundColor:
                layout.fxSelectButtonBackgroundColor

            selectButtonPressedColor:
                layout.fxSelectButtonPressedColor

            selectButtonTextColor:
                layout.fxSelectButtonTextColor

            selectLabelX: layout.fxSelectLabelX
            selectLabelWidth: layout.fxSelectLabelWidth               
        }
    }

    Window {
        id: deck1HotcueWindow

        property real displayScale:
            Screen.devicePixelRatio > 0
            ? Screen.devicePixelRatio
            : 1

        function restorePosition() {
            deck1HotcueWindow.x = layout.deck1HotcueX
            deck1HotcueWindow.y = layout.deck1HotcueY
        }

        x: layout.deck1HotcueX
        y: layout.deck1HotcueY

        width: layout.hotcueModuleWidth / displayScale
        height: layout.hotcueModuleHeight / displayScale

        minimumWidth: width
        maximumWidth: width
        minimumHeight: height
        maximumHeight: height

        visible: deckABViewState.isAdvanced
        color: "transparent"

        title: "Traktor Deck 1 Hotcue Overlay"

        flags: Qt.FramelessWindowHint
            | Qt.BypassWindowManagerHint
            | Qt.WindowStaysOnTopHint
            | Qt.Tool
            | Qt.NoDropShadowWindowHint
            | Qt.WindowDoesNotAcceptFocus

        onVisibleChanged: {
            if (visible)
                deck1PositionTimer.restart()
        }

        Timer {
            id: deck1PositionTimer
            interval: 1
            repeat: false

            onTriggered:
                deck1HotcueWindow.restorePosition()
        }

        Deck.DeckOverlay {
            x: 0
            y: 0

            width: layout.hotcueModuleWidth
            height: layout.hotcueModuleHeight

            scale: 1 / deck1HotcueWindow.displayScale
            transformOrigin: Item.TopLeft

            deck: 1

            hotcueCount: layout.hotcueCount
            hotcueWidth: layout.hotcueWidth
            hotcueHeight: layout.hotcueHeight
            hotcueSpacing: layout.hotcueSpacing

            hotcueFontSize: layout.hotcueFontSize
            hotcueActiveTextColor: layout.hotcueActiveTextColor
            hotcueInactiveTextColor: layout.hotcueInactiveTextColor
            hotcueActiveBackgroundColor: layout.hotcueActiveBackgroundColor
            hotcueInactiveBackgroundColor: layout.hotcueInactiveBackgroundColor
            hotcuePressedBackgroundColor: layout.hotcuePressedBackgroundColor
            hotcueBorderColor: layout.hotcueBorderColor

            debugMode: layout.debugMode
            debugBorderColor: layout.debugBorderColor
            debugTextColor: layout.debugTextColor
            debugFontSize: layout.debugFontSize
        }
    }

    Window {
        id: deck2HotcueWindow

        property real displayScale:
            Screen.devicePixelRatio > 0
            ? Screen.devicePixelRatio
            : 1

        function restorePosition() {
            deck2HotcueWindow.x = layout.deck2HotcueX
            deck2HotcueWindow.y = layout.deck2HotcueY
        }

        x: layout.deck2HotcueX
        y: layout.deck2HotcueY

        width: layout.hotcueModuleWidth / displayScale
        height: layout.hotcueModuleHeight / displayScale

        minimumWidth: width
        maximumWidth: width
        minimumHeight: height
        maximumHeight: height

        visible: deckABViewState.isAdvanced
        color: "transparent"

        title: "Traktor Deck 2 Hotcue Overlay"

        flags: Qt.FramelessWindowHint
            | Qt.BypassWindowManagerHint
            | Qt.WindowStaysOnTopHint
            | Qt.Tool
            | Qt.NoDropShadowWindowHint
            | Qt.WindowDoesNotAcceptFocus

        onVisibleChanged: {
            if (visible)
                deck2PositionTimer.restart()
        }

        Timer {
            id: deck2PositionTimer
            interval: 1
            repeat: false

            onTriggered:
                deck2HotcueWindow.restorePosition()
        }

        Deck.DeckOverlay {
            x: 0
            y: 0

            width: layout.hotcueModuleWidth
            height: layout.hotcueModuleHeight

            scale: 1 / deck2HotcueWindow.displayScale
            transformOrigin: Item.TopLeft

            deck: 2

            hotcueCount: layout.hotcueCount
            hotcueWidth: layout.hotcueWidth
            hotcueHeight: layout.hotcueHeight
            hotcueSpacing: layout.hotcueSpacing

            hotcueFontSize: layout.hotcueFontSize
            hotcueActiveTextColor: layout.hotcueActiveTextColor
            hotcueInactiveTextColor: layout.hotcueInactiveTextColor
            hotcueActiveBackgroundColor: layout.hotcueActiveBackgroundColor
            hotcueInactiveBackgroundColor: layout.hotcueInactiveBackgroundColor
            hotcuePressedBackgroundColor: layout.hotcuePressedBackgroundColor
            hotcueBorderColor: layout.hotcueBorderColor

            debugMode: layout.debugMode
            debugBorderColor: layout.debugBorderColor
            debugTextColor: layout.debugTextColor
            debugFontSize: layout.debugFontSize
        }
    }      

}