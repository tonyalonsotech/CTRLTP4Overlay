import CSI 1.0
import QtQuick 2.0

Item {
    id: root

    property int deck: 1

    readonly property int viewSelectValue: deckViewSelect.value
    readonly property bool isAdvanced: viewSelectValue === 4

    AppProperty {
        id: deckViewSelect
        path: "app.traktor.decks."
              + root.deck
              + ".view.select"
    }
}